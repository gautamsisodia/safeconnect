<?php
ob_start();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { ob_end_clean(); http_response_code(200); exit(); }

include 'dbconnect.php';

$data = json_decode(file_get_contents("php://input"), true);
$email = trim($data['email'] ?? '');
$otp = trim($data['otp'] ?? '');

if(!$email || !$otp){
    ob_end_clean();
    echo json_encode(["success"=>false,"message"=>"Email or OTP empty"]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();

if($res->num_rows == 0){
    ob_end_clean();
    echo json_encode(["success"=>false,"message"=>"User not found"]); 
    exit;
}
$row = $res->fetch_assoc();

if(trim($row['otp']) == trim($otp)){
    $upd = $conn->prepare("UPDATE users SET is_verified=1, otp=NULL WHERE email=?");
    $upd->bind_param("s", $email);
    $upd->execute();
    ob_end_clean();
    echo json_encode([
      "success"=>true,
      "message"=>"Verified",
      "user"=> ["id"=>$row['id'], "name"=>$row['name'], "email"=>$row['email'], "phone"=>$row['phone'], "is_verified"=>1]
    ]);
} else {
    ob_end_clean();
    echo json_encode(["success"=>false,"message"=>"Invalid OTP. DB has: ".$row['otp']]);
}
?>