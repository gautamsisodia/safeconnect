<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

session_start();

include 'dbconnect.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    $rawInput = json_decode(file_get_contents('php://input'), true);
    if ($rawInput) {
        $email = $rawInput['email'] ?? $email;
        $password = $rawInput['password'] ?? $password;
    }
}

$emailClean = $conn->real_escape_string($email);
$passwordClean = $conn->real_escape_string($password);

$sql = "SELECT * FROM users
        WHERE email='$emailClean'
        AND password='$passwordClean'";

$result = $conn->query($sql);

$isApi = (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) ||
         (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false);

if ($result && $result->num_rows > 0)
{
    $row = $result->fetch_assoc();

    $_SESSION['email'] = $row['email'];
    $_SESSION['name'] = $row['name'];

    if ($isApi) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'success',
            'message' => 'Login successful',
            'user' => [
                'user_id' => (int)$row['user_id'],
                'name' => $row['name'],
                'phone' => $row['phone'],
                'email' => $row['email'],
                'registered_at' => $row['registered_at']
            ]
        ]);
        exit();
    }

    header("Location: dashboard.php");
    exit();
}
else
{
    if ($isApi) {
        header('Content-Type: application/json');
        http_response_code(401);
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid Email or Password!'
        ]);
        exit();
    }
    echo "Invalid Email or Password!";
}

$conn->close();

?>
