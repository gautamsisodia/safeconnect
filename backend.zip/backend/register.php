<?php
ob_start();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { ob_end_clean(); http_response_code(200); exit(); }

include 'dbconnect.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;

$data = json_decode(file_get_contents("php://input"), true);
$name = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$phone = trim($data['phone'] ?? '');
$pass_raw = $data['password'] ?? '';
$isResend = $data['resend'] ?? false;
$otp = rand(100000, 999999);

if(!$email){ ob_end_clean(); echo json_encode(["success"=>false,"message"=>"Email empty"]); exit; }

if($isResend){
    $upd = $conn->prepare("UPDATE users SET otp=? WHERE email=?");
    $upd->bind_param("ss", $otp, $email);
    $upd->execute();
    if($upd->affected_rows == 0){ ob_end_clean(); echo json_encode(["success"=>false,"message"=>"User not found"]); exit; }
} else {
    $chk = $conn->prepare("SELECT id FROM users WHERE email=?");
    $chk->bind_param("s",$email);
    $chk->execute();
    if($chk->get_result()->num_rows > 0){ ob_end_clean(); echo json_encode(["success"=>false,"message"=>"Email already exists"]); exit; }
    $hashed = password_hash($pass_raw, PASSWORD_DEFAULT);
    $ins = $conn->prepare("INSERT INTO users (name,email,password,phone,otp,is_verified) VALUES (?,?,?,?,?,0)");
    $ins->bind_param("sssss",$name,$email,$hashed,$phone,$otp);
    $ins->execute();
}

file_put_contents("mail.log", date('Y-m-d H:i:s')." | $email | OTP: $otp \n", FILE_APPEND);

try{
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'safeconnect.project2026@gmail.com';
    $mail->Password = 'tcqnxqkkiyrpivrz';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;
    $mail->SMTPOptions = ['ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]];
    $mail->setFrom('safeconnect.project2026@gmail.com','SafeConnect');
    $mail->addAddress($email, $name ?: $email);
    $mail->isHTML(true);
    $mail->Subject = 'SafeConnect OTP Verification';
    $mail->Body = '<div style="background-color:#121212; padding:30px 0; font-family: Arial, sans-serif;"><div style="max-width:480px; margin:0 auto; background-color:#1E1E1E; border-radius:16px; padding:28px; color:#ffffff;"><h2 style="margin:0 0 20px 0; font-size:20px; font-weight:600;">SafeConnect Email Verification</h2><p style="margin:0; font-size:14px; color:#BBBBBB;">Your OTP is:</p><h1 style="margin:10px 0 16px 0; font-size:36px; letter-spacing:4px; font-weight:800;">'.$otp.'</h1><p style="margin:0; font-size:14px; color:#BBBBBB;">Do not share this OTP with anyone.</p><p style="margin:24px 0 0 0; font-size:12px; color:#777777;">Valid for 10 minutes.</p></div></div>';
    $mail->AltBody = "Your OTP is: $otp";
    $mail->send();
    ob_end_clean();
    echo json_encode(["success"=>true,"message"=>"OTP sent to $email","email"=>$email]);
} catch(Exception $e){
    ob_end_clean();
    file_put_contents("mail.log", "MAIL ERROR: ".$mail->ErrorInfo." \n", FILE_APPEND);
    echo json_encode(["success"=>false,"message"=>"MAIL FAILED: ".$mail->ErrorInfo]);
}
?>